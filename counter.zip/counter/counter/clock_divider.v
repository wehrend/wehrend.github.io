module clock_divider(clk,out);

input wire clk;
output reg [0:25] out = 0;

always @ (posedge clk)
begin
	out <= out + 1;
end

endmodule
