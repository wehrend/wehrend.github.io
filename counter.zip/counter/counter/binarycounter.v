module bin_counter(clk, out);

input wire clk;
output reg [0:7] out;

always @ (posedge clk)
begin
	out <= out + 1;
end

endmodule